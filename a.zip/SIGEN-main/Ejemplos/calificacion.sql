INSERT INTO calificacion VALUES (NULL,'Cumplimiento Agenda');
INSERT INTO calificacion VALUES (NULL,'Resistencia anaeróbica');
INSERT INTO calificacion VALUES (NULL,'Fuerza muscular');
INSERT INTO calificacion VALUES (NULL,'Resistencia musucular');
INSERT INTO calificacion VALUES (NULL,'Flexibilidad');
INSERT INTO calificacion VALUES (NULL,'Resistencia monotonía');
INSERT INTO calificacion VALUES (NULL,'Resilencia');
