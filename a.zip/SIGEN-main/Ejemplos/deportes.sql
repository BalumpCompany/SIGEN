INSERT INTO deporte VALUES (NULL,'Fútbol');
INSERT INTO deporte VALUES (NULL,'Básquetbol');
INSERT INTO deporte VALUES (NULL,'Tenis');
INSERT INTO deporte VALUES (NULL,'Atletismo');
INSERT INTO deporte VALUES (NULL,'Natación');
INSERT INTO deporte VALUES (NULL,'Lucha');
INSERT INTO deporte VALUES (NULL,'Voleibol');
