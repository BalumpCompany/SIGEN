function confirmacion() {
    return confirm("Estás seguro que quieres cerrar sesión?");
}